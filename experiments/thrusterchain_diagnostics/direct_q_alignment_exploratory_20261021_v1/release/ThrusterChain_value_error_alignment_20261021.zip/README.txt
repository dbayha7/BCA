Saved-record exploratory analysis. No checkpoint binaries required.
Start with direct_q_alignment_exploratory_20261021_v1/FINDINGS.md.
Use Python with NumPy and SciPy. From that directory run:
python analysis.py --output reproduced_results
The sibling input folder contains all required saved records.
No model inference, simulator transitions, or training occurs.
results_final is authoritative; preliminary results and missing old-script gap remain disclosed.
The fresh-bank proposal has NOT been executed.
