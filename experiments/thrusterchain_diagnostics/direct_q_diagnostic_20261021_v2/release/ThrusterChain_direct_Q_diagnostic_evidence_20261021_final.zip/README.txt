Analysis-only evidence; no checkpoint binaries or complete historical source closure.
Start with direct_q_diagnostic_20261021_v2/report_assets/RESULTS.md.
Reproduce saved-record reporting with python report_assets/build_report.py from that directory.
NumPy is needed. No model inference or extra rollouts occur.
See PROVENANCE.md for preserved failure history, limits and external model/source requirements.
The final section is report_assets/section.html; an earlier draft is excluded.
